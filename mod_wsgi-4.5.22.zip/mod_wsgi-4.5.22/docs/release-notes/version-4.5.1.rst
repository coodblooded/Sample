=============
Version 4.5.1
=============

Version 4.5.1 of mod_wsgi can be obtained from:

  https://codeload.github.com/GrahamDumpleton/mod_wsgi/tar.gz/4.5.1

Bugs Fixed
----------

1. The CPU user and system time for requests wasn't always being output
   in request finished event data.
